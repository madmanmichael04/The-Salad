"""
This program pops up a welcome window to close to open the main window. On the
main window you add ingredients pressing the add button or remove button to
remove the ingredient from your order. Confirm order button prints the
ingredients. Close button ends the program.
"""
"Imports the program that uses EsayFrame and makes the buttons and labels."
from breezypythongui import EasyFrame
"Imports the program that allows images to be imported"
from tkinter import PhotoImage, N, S, W, E
"Imports the program that allows the destroy function to be used to close the"
"welcome window"
from tkinter import *
"The list that the ingredients will be put into"
entries = []
"WelcomeWindow class that makes the window that opens up tha program to"
"welcome the user"
class WelcomeWindow(EasyFrame):
    "Contains the text and button that will be shown in the window"
    def __init__(self):
        "Titles the window"
        EasyFrame.__init__(self, title = "Welcome")
        "Sets the text box size and the text contained within it and the location"
        "in the window"
        self.welcomeBox = self.addTextArea(text = "Welcome! Close this" +
                                           "window to proceed to your order!",
                                           row = 0, column = 0, columnspan = 2,
                                           width = 60, height = 5)
        "Creates the close button to close that window using the self.closeWindow"
        "command"
        self.addButton(text = "Close", row = 1, column = 1,
                       command = self.closeWindow)
        "Function that both quits and destroys the window to be properly closed"
    def closeWindow(self):
        WelcomeWindow.quit(self)
        WelcomeWindow.destroy(self)
"Class that contains the main window with its ingredients, add and remove"
"buttons, images, labels, and order output"
class Ingredients(EasyFrame):
    "Contains the add and remove buttons for the ingredients and their labels."
    "Also contains the images and the functions tied to the buttons"
    def __init__(self):
        "Title of the window"
        EasyFrame.__init__(self, title = "Customize your order")
        "Label adding Veggies as a category"
        self.addLabel(text = "Veggies", row = 0, column = 0, columnspan = 2)
        "Label specifying romaine lettuce as the ingredient being added or removed"
        self.addLabel(text = "Romaine Lettuce", row = 1, column = 0)
        "Button adding romaine to the list entries"
        self.romaineButton = self.addButton(text = "Add", row = 1, column = 1,
                                            command = self.addRomaine)
        "Button removing romaine from the list entries"
        self.removeRomaineButton = self.addButton(text = "Remove", row = 1,
                                                  column = 2,
                                                  command = self.removeRomaine)
        "Starting the remove button as disabled"
        self.removeRomaineButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        romaineLabel = self.addLabel(text = "", row = 1, column = 3,
                                     sticky = N + S + W + E)
        self.romaineImage = PhotoImage(file = "romainelettuce.gif")
        romaineLabel["image"] = self.romaineImage
        
        "Label specifying spinach is the ingredient being added or removed"
        self.addLabel(text = "Spinach", row = 2, column = 0)
        "Button adding spinach to the entries list"
        self.spinachButton = self.addButton(text = "Add", row = 2, column = 1,
                                            command = self.addSpinach)
        "Button removing spinach from the entries list"
        self.removeSpinachButton = self.addButton(text = "Remove", row = 2,
                                                  column = 2,
                                                  command = self.removeSpinach)
        "Starting off the remove button as disabled"
        self.removeSpinachButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        spinachLabel = self.addLabel(text = "", row  = 2, column = 3,
                                     sticky = N + S + W + E)
        self.spinachImage = PhotoImage(file = "spinach.gif")
        spinachLabel["image"] = self.spinachImage
        "Label specifying celery is the ingredient being added or removed"
        self.addLabel(text = "Celery", row = 3, column = 0)
        "Button adding celery to the entries list"
        self.celeryButton = self.addButton(text = "Add", row = 3, column = 1,
                                           command = self.addCelery)
        "Button removing celery from the entries list"
        self.removeCeleryButton = self.addButton(text = "Remove", row = 3,
                                                 column = 2,
                                                 command = self.removeCelery)
        "Starting of the remove celery button as disabled"
        self.removeCeleryButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        celeryLabel = self.addLabel(text = "", row = 3, column = 3,
                                    sticky = N + S + W + E)
        self.celeryImage = PhotoImage(file = "celery.gif")
        celeryLabel["image"] = self.celeryImage
        "Label specifying broccoli as the ingredient being added or removed"
        self.addLabel(text = "Broccoli", row = 4, column = 0)
        "Button adding broccoli to the entries list"
        self.broccoliButton = self.addButton(text = "Add", row = 4, column = 1,
                                             command = self.addBroccoli)
        "Button removing broccoli from the entries list"
        self.removeBroccoliButton = self.addButton(text = "Remove", row = 4,
                                                   column = 2,
                                                   command = \
                                                   self.removeBroccoli)
        "Starting off the remove broccoli button as disabled"
        self.removeBroccoliButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        broccoliLabel = self.addLabel(text = "", row = 4, column = 3,
                                    sticky = N + S + W + E)
        self.broccoliImage = PhotoImage(file = "broccoli.gif")
        broccoliLabel["image"] = self.broccoliImage
        "Label specifying cucumbers is the ingredient being added or removed"
        self.addLabel(text = "Cucumbers", row = 5, column = 0)
        "Button adding cucumbers to the entries list"
        self.cucumbersButton = self.addButton(text = "Add", row = 5, column = 1,
                                              command = self.addCucumbers)
        "Button removing cucumbers from the entries list"
        self.removeCucumbersButton = self.addButton(text = "Remove", row = 5,
                                                    column = 2,
                                                    command = \
                                                    self.removeCucumbers)
        "Starting off the remove cucumbers button as being disabled"
        self.removeCucumbersButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        cucumberLabel = self.addLabel(text = "", row = 5, column = 3,
                                    sticky = N + S + W + E)
        self.cucumberImage = PhotoImage(file = "cucumber.gif")
        cucumberLabel["image"] = self.cucumberImage
        "Label specifying tomatoes are the ingredient being added or removed"
        self.addLabel(text = "Tomatoes", row = 6, column = 0)
        "Button adding tomatoes to the entries list"
        self.tomatoesButton = self.addButton(text = "Add", row = 6, column = 1,
                                             command = self.addTomatoes)
        "Button removing tomatoes from the entries list"
        self.removeTomatoesButton = self.addButton(text = "Remove", row = 6,
                                                   column = 2,
                                                   command = \
                                                   self.removeTomatoes)
        "Starting off the remove tomatoes button as being disabled"
        self.removeTomatoesButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        tomatoLabel = self.addLabel(text = "", row = 6, column = 3,
                                    sticky = N + S + W + E)
        self.tomatoImage = PhotoImage(file = "tomato.gif")
        tomatoLabel["image"] = self.tomatoImage
        "Label describing the new category starting the ingredients in a different row"
        self.addLabel(text = "Protien", row = 0, column = 4, columnspan = 2)
        "Label specifying grilled chicken is the ingredient being added or removed"
        self.addLabel(text = "Grilled Chicken", row = 1, column = 4)
        "Button adding grilled chicken to the entries list"
        self.chickenButton = self.addButton(text = "Add", row = 1, column = 5,
                                            command = self.addChicken)
        "Button removing grilled chicken from the entries list"
        self.removeChickenButton = self.addButton(text = "Remove", row = 1,
                                                  column = 6,
                                                  command = self.removeChicken)
        "Starting off the remove chicken button and being disabled"
        self.removeChickenButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        chickenLabel = self.addLabel(text = "", row = 1, column = 7,
                                    sticky = N + S + W + E)
        self.chickenImage = PhotoImage(file = "chicken.gif")
        chickenLabel["image"] = self.chickenImage
        "Label specifying turkey is the ingredient being added or removed"
        self.addLabel(text = "Turkey", row = 2, column = 4)
        "Button adding turkey to the entries list"
        self.turkeyButton = self.addButton(text = "Add", row = 2, column = 5,
                                           command = self.addTurkey)
        "Button removing turkey from the entries list"
        self.removeTurkeyButton = self.addButton(text = "Remove", row = 2,
                                                 column = 6,
                                                 command = self.removeTurkey)
        "Starting off the remove turkey button and being disabled"
        self.removeTurkeyButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        turkeyLabel = self.addLabel(text = "", row = 2, column = 7,
                                    sticky = N + S + W + E)
        self.turkeyImage = PhotoImage(file = "turkey.gif")
        turkeyLabel["image"] = self.turkeyImage
        "Label specufying chickpeas as the ingredient being added or removed"
        self.addLabel(text = "Chickpeas", row = 3, column = 4)
        "Button adding chickpeas to the entries list"
        self.chickpeasButton = self.addButton(text = "Add", row = 3,
                                              column = 5,
                                              command = self.addChickpeas)
        "Button removing chickpeas from the entries list"
        self.removeChickpeasButton = self.addButton(text = "Remove", row = 3,
                                                    column = 6,
                                                    command = \
                                                    self.removeChickpeas)
        "Starting off the remove chickpeas button and being disabled"
        self.removeChickpeasButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        chickpeaLabel = self.addLabel(text = "", row = 3, column = 7,
                                    sticky = N + S + W + E)
        self.chickpeaImage = PhotoImage(file = "chickpea.gif")
        chickpeaLabel["image"] = self.chickpeaImage
        "Label setting dressing as the new category in a different column"
        self.addLabel(text = "Dressing", row = 0, column = 8, columnspan = 2)
        "Label specifying ranch as the ingredient being added or removed"
        self.addLabel(text = "Ranch", row = 1, column = 8)
        "Button adding ranch to the entries list"
        self.ranchButton = self.addButton(text = "Add", row = 1, column = 9,
                                          command = self.addRanch)
        "Button removing ranch from the entries list"
        self.removeRanchButton = self.addButton(text = "Remove", row = 1,
                                                column = 10,
                                                command = self.removeRanch)
        "Starting off the remove ranch button as being disabled"
        self.removeRanchButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        ranchLabel = self.addLabel(text = "", row = 1, column = 11,
                                    sticky = N + S + W + E)
        self.ranchImage = PhotoImage(file = "ranch.gif")
        ranchLabel["image"] = self.ranchImage
        "Label specifying thousand island dressing as the ingredient being added"
        "or removed"
        self.addLabel(text = "Thousand Island", row = 2, column = 8)
        "Button adding thousand island dressing to the entries list"
        self.islandButton = self.addButton(text = "Add", row = 2, column = 9,
                                           command = self.addIsland)
        "Button removing thousand island dressing from the entries list"
        self.removeIslandButton = self.addButton(text = "Remove", row = 2,
                                                 column = 10,
                                                 command = self.removeIsland)
        "Starting of the remove island button as being disabbled"
        self.removeIslandButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        islandLabel = self.addLabel(text = "", row = 2, column = 11,
                                    sticky = N + S + W + E)
        self.islandImage = PhotoImage(file = "island.gif")
        islandLabel["image"] = self.islandImage
        "Label specifying Balsamic Vinaigrette as the ingredient being added"
        "or removed"
        self.addLabel(text = "Balsamic Vinaigrette", row = 3, column = 8)
        "Button adding Balsamic Vinaigrette to the entries list"
        self.balsamicButton = self.addButton(text = "Add", row = 3, column = 9,
                                             command = self.addBalsamic)
        "Button removing Balsamic Vinaigrette from the entries list"
        self.removeBalsamicButton = self.addButton(text = "Remove", row = 3,
                                                   column = 10,
                                                   command = \
                                                   self.removeBalsamic)
        "Starting off the remove balsamic button as being disabled"
        self.removeBalsamicButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        balsamicLabel = self.addLabel(text = "", row = 3, column = 11,
                                    sticky = N + S + W + E)
        self.balsamicImage = PhotoImage(file = "balsamic.gif")
        balsamicLabel["image"] = self.balsamicImage
        "Label specifying caesar dressing as the ingredient being added or removed"
        self.addLabel(text = "Caesar", row = 4, column = 8)
        "Button adding caesar dressing to the entries list"
        self.caesarButton = self.addButton(text = "Add", row = 4, column = 9,
                                           command = self.addCaesar)
        "Button removing caesar dressing from the entries list"
        self.removeCaesarButton = self.addButton(text = "Remove", row = 4,
                                                 column = 10,
                                                 command = self.removeCaesar)
        "Starting off the remove caesar button as being disabled"
        self.removeCaesarButton['state'] = 'disabled'
        "Labeling the image and associating that label with the image and centering"
        "the image with sticky"
        caesarLabel = self.addLabel(text = "", row = 4, column = 11,
                                    sticky = N + S + W + E)
        self.caesarImage = PhotoImage(file = "caesar.gif")
        caesarLabel["image"] = self.caesarImage
        "Button that takes all of the entries in the entries list and putting them"
        "on the text field"
        self.addButton(text = "Confirm Order", row = 7, column = 0,
                       columnspan = 2, command = self.confirm)
        "Label of the text field that contains the ingredients in the users order"
        self.addLabel(text = "Your Order:", row = 7, column = 1)
        "Text field containing the ingredients to the users order, also resizing the"
        "text field to fit within the window"
        self.ingredientList = self.addTextArea(text = "", row = 7, column = 2,
                                               width = 20, columnspan = 2,
                                               height = 15)
        "Button closing the Ingredients window, thus ending the program"
        self.addButton(text = "Close", row = 7, column = 5,
                       command = self.closeWindow)
        "Function that closes the Ingredients window"       
    def closeWindow(self):
        Ingredients.quit(self)
        Ingredients.destroy(self)
        "Function adding romaine to the entries list, and disabling the add romaine"
        "after being pushed and enabling the remove romaine button"
    def addRomaine(self):
        entries.append("Romaine Lettuce\n")
        self.romaineButton['state'] = 'disabled'
        self.removeRomaineButton['state'] = 'active'
        "Function removing romaine from the entries list, and disabling the remove romaine"
        "after being pushed and enabling the add romaine button"
    def removeRomaine(self):
        entries.remove("Romaine Lettuce\n")
        self.removeRomaineButton['state'] = 'disabled'
        self.romaineButton['state'] = 'active'
        "Function adding spinach to the entries list, and disabling the add spinach"
        "after being pushed and enabling the remove spinach button"
    def addSpinach(self):
        entries.append("Spinach\n")
        self.spinachButton['state'] = 'disabled'
        self.removeSpinachButton['state'] = 'active'
        "Function removing spinach from the entries list, and disabling the remove"
        "spinach button after being pushed and enabling the add romaine button"
    def removeSpinach(self):
        entries.remove("Spinach\n")
        self.removeSpinachButton['state'] = 'disabled'
        self.spinachButton['state'] = 'active'
        "Function adding celery to the entries list, and disabling the add celery"
        "after being pushed and enabling the remove celery button"
    def addCelery(self):
        entries.append("Celery\n")
        self.celeryButton['state'] = 'disabled'
        self.removeCeleryButton['state'] = 'active'
        "Function removing celery from the entries list, and disabling the remove"
        "celery after being pushed and enabling the add celery button"
    def removeCelery(self):
        entries.remove("Celery\n")
        self.removeCeleryButton['state'] = 'disabled'
        self.celeryButton['state'] = 'active'
        "Function adding broccoli to the entries list, and disabling the add broccoli"
        "after being pushed and enabling the remove broccoli button"
    def addBroccoli(self):
        entries.append("Broccoli\n")
        self.broccoliButton['state'] = 'disabled'
        self.removeBroccoliButton['state'] = 'active'
        "Function removing romaine from the entries list, and disabling the remove"
        "broccoli after being pushed and enabling the add broccoli button"
    def removeBroccoli(self):
        entries.remove("Broccoli\n")
        self.removeBroccoliButton['state'] = 'disabled'
        self.broccoliButton['state'] = 'active'
        "Function adding cucumbers to the entries list, and disabling the add cucumbers"
        "after being pushed and enabling the remove remove cucumbers button"
    def addCucumbers(self):
        entries.append("Cucumbers\n")
        self.cucumbersButton['state'] = 'disabled'
        self.removeCucumbersButton['state'] = 'active'
        "Function removing cucumbers from the entries list, and disabling the remove"
        "cucumbers after being pushed and enabling the add cucumbers button"
    def removeCucumbers(self):
        entries.remove("Cucumbers\n")
        self.removeCucumbersButton['state'] = 'disabled'
        self.cucumbersButton['state'] = 'active'
        "Function adding tomatoes to the entries list, and disabling the add tomatoes"
        "after being pushed and enabling the remove tomatoes button"
    def addTomatoes(self):
        entries.append("Tomatoes\n")
        self.tomatoesButton['state'] = 'disabled'
        self.removeTomatoesButton['state'] = 'active'
        "Function removing tomatoes from the entries list, and disabling the remove"
        "tomatoes after being pushed and enabling the add tomatoes button"
    def removeTomatoes(self):
        entries.remove("Tomatoes\n")
        self.removeTomatoesButton['state'] = 'disabled'
        self.tomatoesButton['state'] = 'active'
        "Function adding chicken to the entries list, and disabling the add chicken"
        "after being pushed and enabling the remove chicken button"
    def addChicken(self):
        entries.append("Chicken\n")
        self.chickenButton['state'] = 'disabled'
        self.removeChickenButton['state'] = 'active'
        "Function removing chicken from the entries list, and disabling the remove"
        "chicken after being pushed and enabling the add chicken button"
    def removeChicken(self):
        entries.remove("Chicken\n")
        self.removeChickenButton['state'] = 'disabled'
        self.chickenButton['state'] = 'active'
        "Function adding turkey to the entries list, and disabling the add turkey"
        "after being pushed and enabling the remove turkey button"
    def addTurkey(self):
        entries.append("Turkey\n")
        self.turkeyButton['state'] = 'disabled'
        self.removeTurkeyButton['state'] = 'active'
        "Function removing turkey from the entries list, and disabling the remove"
        "turkey after being pushed and enabling the add turkey button"
    def removeTurkey(self):
        entries.remove("Turkey\n")
        self.removeTurkeyButton['state'] = 'disabled'
        self.turkeyButton['state'] = 'active'
        "Function adding chickpeas to the entries list, and disabling the add chickpeas"
        "after being pushed and enabling the remove chickpeas button"
    def addChickpeas(self):
        entries.append("Chickpeas\n")
        self.chickpeasButton['state'] = 'disabled'
        self.removeChickpeasButton['state'] = 'active'
        "Function removing chickpeas from the entries list, and disabling the remove"
        "chickpeas after being pushed and enabling the add chickpeas button"
    def removeChickpeas(self):
        entries.remove("Chickpeas\n")
        self.removeChickpeasButton['state'] = 'disabled'
        self.chickpeasButton['state'] = 'active'
        "Function adding ranch dressing to the entries list, and disabling the add"
        "ranch after being pushed and enabling the remove ranch button"
    def addRanch(self):
        entries.append("Ranch Dressing\n")
        self.ranchButton['state'] = 'disabled'
        self.removeRanchButton['state'] = 'active'
        "Function removing ranch dressing from the entries list, and disabling the"
        "remove ranch after being pushed and enabling the add ranch button"
    def removeRanch(self):
        entries.remove("Ranch Dressing\n")
        self.removeRanchButton['state'] = 'disabled'
        self.ranchButton['state'] = 'active'
        "Function adding thousand island dressing to the entries list, and disabling"
        "the add island after being pushed and enabling the remove island button"
    def addIsland(self):
        entries.append("Thousand Island Dressing\n")
        self.islandButton['state'] = 'disabled'
        self.removeIslandButton['state'] = 'active'
        "Function removing thousand island dressing from the entries list, and"
        "disabling the remove island after being pushed and enabling the add"
        "island button"
    def removeIsland(self):
        entries.remove("Thousand Island Dressing\n")
        self.removeIslandButton['state'] = 'disabled'
        self.islandButton['state'] = 'active'
        "Function adding balsamic vinaigrette to the entries list, and disabling the"
        "add balsamic after being pushed and enabling the remove balsamic button"
    def addBalsamic(self):
        entries.append("Balsamic Vinaigrette\n")
        self.balsamicButton['state'] = 'disabled'
        self.removeBalsamicButton['state'] = 'active'
        "Function removing balsamic from the entries list, and disabling the remove"
        "balsamic after being pushed and enabling the add balsamic button"
    def removeBalsamic(self):
        entries.remove("Balsamic Vinaigrette\n")
        self.removeBalsamicButton['state'] = 'disabled'
        self.balsamicButton['state'] = 'active'
        "Function adding caesar dressing to the entries list, and disabling the add"
        "romaine caesar after being pushed and enabling the remove caesar button"
    def addCaesar(self):
        entries.append("Caesar Dressing\n")
        self.caesarButton['state'] = 'disabled'
        self.removeCaesarButton['state'] = 'active'
        "Function removing caesar dressing from the entries list, and disabling the"
        "remove caesar after being pushed and enabling the add caesar button"
    def removeCaesar(self):
        entries.remove("Caesar Dressing\n")
        self.removeCaesarButton['state'] = 'disabled'
        self.caesarButton['state'] = 'active'
        "Function displaying an error message when the text fiels is empty and if not"
        "displaying the ingredients in the users order in the text field"
    def confirm(self):
        if entries == []:
            self.messageBox(title = "Error",
                            message = "Must add an ingredient.")
        else:
            self.ingredientList.setText("".join(entries))
"Executing the welcome window class"
WelcomeWindow().mainloop()
"Executing the Ingredients class"
Ingredients().mainloop()

        

        
